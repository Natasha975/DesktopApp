﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда
{
    /// <summary>
    /// Логика взаимодействия для RegProductWindow.xaml
    /// </summary>
    public partial class RegProductWindow : Window
    {
        string articleNumber;
        public RegProductWindow(string articleNumber)
        {
            InitializeComponent();
            this.articleNumber = articleNumber;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (var db = new TradesEntities())
            {
                var selectedProducts = db.Product.FirstOrDefault(p => p.ProductArticleNumber == articleNumber);
                lbNumber.Content = selectedProducts.ProductArticleNumber;
                tbArt.Text = selectedProducts.ProductName;
                tbNameProus.Text = selectedProducts.ProductManufacturer;
                tbCount.Text = selectedProducts.ProductQuantityInStock.ToString();
                tbProductDescription.Text = selectedProducts.ProductDescription;
                lbImage.ItemsSource = selectedProducts.ProductPhoto;
            }
        }

        private void btSave_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new TradesEntities())
            {
                var selectedProducts = db.Product.FirstOrDefault(p => p.ProductArticleNumber == articleNumber);
                selectedProducts.ProductName = tbArt.Text;
                selectedProducts.ProductDescription = tbNameProus.Text;
                selectedProducts.ProductDescription = tbProductDescription.Text;
                try
                {
                    db.SaveChanges();
                    MessageBox.Show("Данные успешно обновлены");
                }
                catch
                {
                    MessageBox.Show("Ошибка");
                }
            }
        }
    }
}
