﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда
{
    /// <summary>
    /// Логика взаимодействия для MenagerWindow.xaml
    /// </summary>
    public partial class MenagerWindow : Window
    {
        public MenagerWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Unpaot();
        }
        public void Unpaot()
        {
            using (var db = new TradesEntities())
            {
                var products = db.Product.ToList();
                lvListProduct.ItemsSource = products;
            }
        }

        private void tbSearch_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (tbSearch.Text == "")
            {
                Unpaot();
            }
            else
            {
                using (var db = new TradesEntities())
                {
                    var selectedProducts = db.Product.Where(p => p.ProductArticleNumber.ToLower().Contains(tbSearch.Text.ToLower()) ||
                        p.ProductName.ToLower().Contains(tbSearch.Text.ToLower()) ||
                        p.ProductCategory.ToLower().Contains(tbSearch.Text.ToLower()) ||
                        p.ProductManufacturer.ToLower().Contains(tbSearch.Text.ToLower()) ||
                        p.ProductStatus.ToLower().Contains(tbSearch.Text.ToLower()));
                    lvListProduct.ItemsSource = selectedProducts.ToList();
                }
            }
        }
    }
}
